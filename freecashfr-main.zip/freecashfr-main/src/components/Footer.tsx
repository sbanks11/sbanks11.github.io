import freecashLogo from "@/assets/freecash-logo.png";

const Footer = () => {
  return (
    <footer className="border-t bg-card py-12">
      <div className="container mx-auto px-4">
        <div className="flex justify-center">
          <img src={freecashLogo} alt="Freecash" className="h-24" />
        </div>
      </div>
    </footer>
  );
};

export default Footer;
