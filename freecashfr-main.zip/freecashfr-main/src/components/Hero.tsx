import { Button } from "@/components/ui/button";
import heroImage from "@/assets/hero-image.jpg";

const Hero = () => {
  const scrollToSteps = () => {
    document.getElementById('steps')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background Image with Overlay */}
      <div 
        className="absolute inset-0 z-0"
        style={{
          backgroundImage: `url(${heroImage})`,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
        }}
      >
        <div className="absolute inset-0 bg-gradient-to-b from-background/95 via-background/85 to-background" />
      </div>

      {/* Content */}
      <div className="container relative z-10 px-4 text-center">
        <div className="mx-auto max-w-4xl">
          {/* Main Heading */}
          <h1 className="mb-6 text-5xl font-bold leading-tight tracking-tight md:text-7xl">
            <span className="text-primary">Gagne de</span>{" "}
            <span className="text-white">l'argent</span>{" "}
            en jouant à des jeux.
          </h1>

          {/* Subheading */}
          <p className="mb-8 text-xl text-muted-foreground md:text-2xl">
            La plupart des nouveaux utilisateurs gagnent 50 € dès leur premier jour en jouant aux jeux qu'ils aiment déjà.
          </p>

          {/* CTA Button */}
          <Button 
            variant="hero" 
            size="lg" 
            className="text-lg px-12 py-6 h-auto"
            onClick={scrollToSteps}
          >
            Commencez maintenant 🎁
          </Button>
        </div>
      </div>

      {/* Scroll indicator */}
      <div className="absolute bottom-8 left-0 right-0 z-10 flex justify-center animate-bounce">
        <div className="flex flex-col items-center gap-2 text-muted-foreground">
          <span className="text-sm text-center">Fais défiler pour en savoir</span>
          <svg
            className="h-6 w-6"
            fill="none"
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth="2"
            viewBox="0 0 24 24"
            stroke="currentColor"
          >
            <path d="M19 14l-7 7m0 0l-7-7m7 7V3"></path>
          </svg>
        </div>
      </div>
    </section>
  );
};

export default Hero;
