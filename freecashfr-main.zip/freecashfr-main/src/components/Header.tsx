import freecashLogo from "@/assets/freecash-logo.png";

const Header = () => {
  return (
    <header className="fixed top-0 left-0 right-0 z-50 border-b bg-background/80 backdrop-blur-lg">
      <div className="container mx-auto px-4">
        <div className="flex h-20 items-center justify-center">
          {/* Logo */}
          <img 
            src={freecashLogo} 
            alt="FreeCash" 
            className="h-16 w-auto md:h-20"
          />
        </div>
      </div>
    </header>
  );
};

export default Header;
