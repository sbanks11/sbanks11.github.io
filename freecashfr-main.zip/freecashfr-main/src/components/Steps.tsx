import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

const steps = [
  {
    number: "1",
    emoji: "📍",
    title: "Inscris-toi sur Freecash",
    description: "Clique sur le bouton ci-dessous",
  },
  {
    number: "2",
    emoji: "🚨",
    title: "Accomplis 3 à 5 missions de jeu pour être payé instantanément !",
    description: "Plus tu joues, plus tu gagnes",
    important: true,
  },
  {
    number: "3",
    emoji: "🎉",
    title: "Récupère ta récompense !",
    description: "Les utilisateurs réguliers gagnent 200 à 400 € par semaine, alors joue tous les jours !",
  },
];

const Steps = () => {
  return (
    <section id="steps" className="py-20 px-4">
      <div className="container mx-auto max-w-6xl">
        {/* Section Header */}
        <div className="mb-16 text-center">
          <h2 className="mb-4 text-4xl font-bold md:text-5xl">
            <span className="bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
              Suivez les étapes et
            </span>{" "}
            <span className="text-white">
              commencez à gagner dès aujourd'hui !
            </span>
          </h2>
          <p className="text-xl text-muted-foreground">
            Juste 4 étapes simples entre toi et un revenu régulier
          </p>
        </div>

        {/* Steps Grid */}
        <div className="grid gap-6 md:grid-cols-2 lg:gap-8">
          {steps.map((step, index) => (
            <Card 
              key={index}
              className="group relative overflow-hidden border-2 transition-all duration-300 hover:border-primary hover:shadow-[var(--shadow-soft)]"
            >
              {step.important && (
                <div className="absolute right-0 top-0 bg-destructive px-4 py-1 text-xs font-bold text-destructive-foreground">
                  IMPORTANTE
                </div>
              )}
              <CardContent className="p-8">
                <div className="mb-4 flex items-start gap-4">
                  {/* Step Number */}
                  <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-primary to-accent text-2xl font-bold text-primary-foreground">
                    {step.number}
                  </div>
                  {/* Emoji */}
                  <div className="text-4xl transition-transform duration-300 group-hover:scale-110">
                    {step.emoji}
                  </div>
                </div>
                
                {/* Content */}
                <h3 className="mb-3 text-xl font-bold leading-tight">
                  {step.title}
                </h3>
                <p className="text-muted-foreground">
                  {step.description}
                </p>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* CTA Section */}
        <div className="mt-16 text-center">
          <div className="mx-auto max-w-2xl rounded-2xl bg-gradient-to-br from-primary/10 to-accent/10 p-8 backdrop-blur-sm md:p-12">
            <h3 className="mb-4 text-2xl md:text-3xl font-bold whitespace-nowrap">Prêt à gagner ?</h3>
            <p className="mb-8 text-lg text-muted-foreground">
              Commence maintenant et termine toutes les étapes pour être payé !
            </p>
            <Button 
              variant="hero" 
              size="lg" 
              className="text-sm md:text-xl px-8 md:px-14 py-5 md:py-7 h-auto w-full sm:w-auto"
              onClick={() => window.open('https://uplevelrewarded.com/aff_c?offer_id=3259&aff_id=54313', '_blank')}
            >
              Commencer mon aventure 🚀
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Steps;
